1:"$Sreact.fragment"
2:I[97367,["/_next/static/chunks/0n2mhyl-m9pny.js","/_next/static/chunks/0d3shmwh5_nmn.js"],"ViewportBoundary"]
3:I[97367,["/_next/static/chunks/0n2mhyl-m9pny.js","/_next/static/chunks/0d3shmwh5_nmn.js"],"MetadataBoundary"]
4:"$Sreact.suspense"
5:I[27201,["/_next/static/chunks/0n2mhyl-m9pny.js","/_next/static/chunks/0d3shmwh5_nmn.js"],"IconMark"]
0:{"rsc":["$","$1","h",{"children":[["$","meta",null,{"name":"robots","content":"noindex"}],["$","$L2",null,{"children":[["$","meta","0",{"charSet":"utf-8"}],["$","meta","1",{"name":"viewport","content":"width=device-width, initial-scale=1"}]]}],["$","div",null,{"hidden":true,"children":["$","$L3",null,{"children":["$","$4",null,{"name":"Next.Metadata","children":[["$","title","0",{"children":"Last Writes"}],["$","meta","1",{"name":"description","content":"Digital legacy vault dashboard"}],["$","link","2",{"rel":"icon","href":"/favicon.ico?favicon.0x3dzn~oxb6tn.ico","sizes":"256x256","type":"image/x-icon"}],["$","$L5","3",{}]]}]}]}],["$","meta",null,{"name":"next-size-adjust","content":""}]]}],"isPartial":false,"staleTime":300,"varyParams":null,"buildId":"MUjZn1NavhpAuAn15C224"}
