globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/03~yq9q893hmn.js"
  ],
  "lowPriorityFiles": [
    "static/MJZIq-nsLpc9v6L9yNBUu/_buildManifest.js",
    "static/MJZIq-nsLpc9v6L9yNBUu/_ssgManifest.js",
    "static/MJZIq-nsLpc9v6L9yNBUu/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/05tsy9pxtuyv0.js",
    "static/chunks/0pqt~8bl3ukh4.js",
    "static/chunks/0257pdz1-imal.js",
    "static/chunks/0r7m44~cm1a3r.js",
    "static/chunks/turbopack-0.g4d.3qr1n25.js"
  ]
};
